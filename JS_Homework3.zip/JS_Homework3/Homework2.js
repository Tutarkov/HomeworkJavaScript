// part 1

var year = prompt("Input you birth year:");
switch((year - 4) % 12) {
    case 0:
        console.log("Sign:" + " " + "Rat");
        break;
    case 1:
        console.log("Sign:" + " " + "Ox");
        break;
    case 2:
        console.log("Sign:" + " " + "Tiger");
        break;
    case 3:
        console.log("Sign:" + " " + "Rabbit");
        break;
    case 4:
        console.log("Sign:" + " " + "Dragon");
    case 5:
        console.log("Sign:" + " " + "Snake");
        break;
    case 6:
        console.log("Sign:" + " " + "Horse");
        break;
    case 7:
        console.log("Sign:" + " " + "Goat");
        break;
    case 8:
        console.log("Sign:" + " " + "Monkey");
        break;
    case 9:
        console.log("Sign:" + " " + "Rooster");
        break;
    case 10:
        console.log("Sign:" + " " + "Dog");
        break;
    case 11:
        console.log("Sign:" + " " + "Pig");
        break;
    default:
            console.log("Invalid input!");
            break;
}

// part 2


var car = {name: "Fiat", year: "1999"};

function type(value)
{
let types = [Object, Boolean, Number, String, undefined], x, len;
    
if (typeof value === "object" || typeof value === "function") 
    {
     for (x = 0, len = types.length; x < len; x++) 
     {
            if (value instanceof types[x])
            {
                return types[x];
            }
      }
    }
    
    return typeof value;
}
console.log(type(125));
console.log(type('hiiii'));
console.log(type(true));
console.log(type(car));
console.log(type(undefined));

// part 3

function dogAge(age) {
    var yearsDog = 7*age;
    console.log(`Tvoeto kuce ima: ${yearsDog}godini`);
}

dogAge(5);

// part 4

function money(cash)
{
    var req = prompt("Vnesi suma na pari:");
    if(req > cash){
        console.log("Nema dovolno pari");
    } else{
        var ostanato = cash - req;
        console.log("Vie izvadivte" + " " + req);
        console.log("Ima preostanato:" + " " + ostanato);
    }
}

money(3500);

// bonus - years

function calculateAge(birthYear) {
    const currentYear =  new Date().getFullYear();
    var years = currentYear - birthYear;
    console.log("You are" + " " + years + " " + "years old");
}

calculateAge(1999);
calculateAge(1990);
calculateAge(1971);


