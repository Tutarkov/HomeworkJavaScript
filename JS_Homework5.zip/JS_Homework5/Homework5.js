//part 1
//Write a JavaScript program to write the sum of squares of the numbers from 101 to 150
function sumPow(){
    let sum = 0;
    let tmp=0;
    for(let i=101; i<=150; i++){
        sum=0;
        sum += Math.pow(i, 2);
        //console.log(sum);
        tmp +=sum;
    }
    console.log(tmp); 
}
sumPow();
//797925

//part 2

var array = [];
var count={};
function findNumber(array){
for(var i=0; i<array.length;i++){
    var number = array[i];
   if(count[number] = count[number]){
   count[number] = count[number] + 1;
   } 
    else{
        count[number] = 1;
   }
   console.log(count);
}
}
findNumber([2, 2, 5, 6, 4, 2, 1, 5, 7, 3, 4, 4]);
//findNumber([5, 10, 11, 20, 10, 22, 6, 5, 10, 25, 100, 62, 66, 62]);


//part 3

var nizaaa = prompt("Vnesi niza");
var prazna1 = [];
var prazna2 = [];

function oddEv(){
    
   for(var i=0; i<nizaaa.length; i++){
    var evv = nizaaa[i];
    if(evv % 2 == 0){
        prazna1.push(evv); 
    }  
}
console.log("Even:" + prazna1);
for(var i=0; i<nizaaa.length; i++){
    var odd = nizaaa[i];
    if(odd % 2 == 1){
        prazna2.push(odd);
        
    }
    
}
console.log("Odd:" + prazna2);
}
oddEv(nizaaa);

