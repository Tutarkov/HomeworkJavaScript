var a = 2;
var b ="3";

var result = a + b ;
console.log("a:");
console.log(a);
console.log("b:");
console.log(b);


console.log(a+b) // ne gi sobira biidejki a e numb a b e string i gi dava 23

// 2 Povrsina na krug

var r = 15;
var valofPI = 3.14 ;

var result = (r*r) * valofPI;
console.log("Povrsina na krug:");
console.log(result);

// 3 cena na telefon

var price = 119.95;
var numphone = 30;
var tax = 0.05; // pretvoreno od 5%
var totaltax = (numphone*price)*tax;

var pricesum = (price*numphone)+totaltax
console.log("Price of 30 phones with tax")
console.log(pricesum);

// bonus

var qualityofphones = parseInt(prompt("quantity of phones"));
var tax = parseInt(prompt("tax"));
var taxtrans = (tax/100);
var totaltax1= (qualityofphones*price)*taxtrans

var price = 119.95;

var pricesum = (price*qualityofphones)+totaltax1
console.log("Price of quantity of phones with tax")
console.log(pricesum);


