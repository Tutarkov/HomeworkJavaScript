// part 1 
//Create a function called tellStory()
// The function should accept an array of 3 strings as an argument: name, mood, activity ( All strings )
// The function should return one big string with a story made from the arguments
// Example: This is *name*. *name* is a nice person. Today they are *mood*. They are *activity* all day. The end.
// The value that is returned from the function should be printed in the console or in alert


let story = ['Viki', 'happy', 'running'];
 function tellStory(){
    alert("This is" + " " + story[0] + "." + " " + story[0] + " " + "is a nice person" + "." + " " + "Today they are" + " " + story[1] + "." + "They are" + " " + story[2] + " " + "all day. The end");
    console.log("This is" + " " + story[0] + "." + " " + story[0] + " " + "is a nice person" + "." + " " + "Today they are" + " " + story[1] + "." + "They are" + " " + story[2] + " " + "all day. The end");
 }

 tellStory(story);

 //part2
// Write a function that will take an array of 5 numbers as a parameter and return the sum.
// Print it in the console or in alert
// BONUS**: Write another function called validateNumber() that checks if a number is a valid number and call it for every number. If one of the numbers of the array is invalid show an error message instead of a result

let numbers=[5, 10, 15, 20, 25];
function  number1(){
    let sum =  numbers[0] + numbers[1] + numbers[2] + numbers[3] + numbers[4];
    alert("The sum of" + " " + numbers[0] + "," +  numbers[1] + "," + numbers[2] + "," + numbers[3] + " " + "and" +" "+ numbers[4] +" "+ "is"+" " + sum);
    console.log("The sum of" + " " + numbers[0] + "," +  numbers[1] + "," + numbers[2] + "," + numbers[3] + " " + "and" +" "+ numbers[4] +" "+ "is"+" " + sum);
}

number1(numbers);

//part 3

var aarr = ["Hello", "there", "students", "of", "SEDC", "!"];
var aar = new Array();
for (var i = 0; i < aarr.length; i++) {
   aar = aar + aarr[i] + " "; //aar += aarr[i] + " ";
}
console.log(aar);

//part 4

  var broevi = [3, 5, 6, 8, 11, 50, 1100, 34, 1 , 2220, 2 , 5430, 25];
  function suma(broevi){
    var dolzina = broevi.length;
    var min = Infinity;
    var max = -Infinity;
    while (dolzina--) {
      if (broevi[dolzina] < min) {
        min = broevi[dolzina];
      } else 
      if(broevi[dolzina] > max){
        max = broevi[dolzina];
      }
    }
    var sumMaxMin =0;
    sumMaxMin = sumMaxMin + max + min;
    console.log(sumMaxMin);
  }
  suma(broevi);