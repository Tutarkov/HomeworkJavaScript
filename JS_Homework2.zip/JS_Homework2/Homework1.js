// part 1

var nameSurname = prompt("Input your name and surname:");
console.log("Hello" + "," + " " + "I" + " "+ "am" + " " + nameSurname);

// part 2

var year = prompt("Input you birth year:");

if((year - 4) % 12 == 0)
{
    console.log("Sign:" + " " + "Rat");
} else if((year - 4) % 12 == 1) {
    console.log("Sign:" + " " + "Ox");
} else if((year - 4) % 12 == 2) {
    console.log("Sign:" + " " + "Tiger");
} else if((year - 4) % 12 == 3) {
    console.log("Sign:" + " " + "Rabbit");
} else if((year - 4) % 12 == 4) {
    console.log("Sign:" + " " + "Dragon");
} else if((year - 4) % 12 == 5) {
    console.log("Sign:" + " " + "Snake");
} else if((year - 4) % 12 == 6) {
    console.log("Sign:" + " " + "Horse");
} else if((year - 4) % 12 == 7) {
    console.log("Sign:" + " " + "Goat");
} else if((year - 4) % 12 == 8) {
    console.log("Sign:" + " " + "Monkey");
} else if((year - 4) % 12 == 9) {
    console.log("Sign:" + " " + "Rooster");
} else if((year - 4) % 12 == 10) {
    console.log("Sign:" + " " + "Dog");
} else {
    console.log("Sign:" + " " + "Pig");
}

// bonus 

var number1 = prompt("Input number:");
var number2 = prompt("Input number:");
var number3 = prompt("Input number:");
var number4 = prompt("Input number:");
var number5 = prompt("Input number:");

if (number1>number2 && number1>number3 && number1>number4 && number1>number5)
{
    console.log("Max Number:" + " " + number1);
}
else if (number2>number1 && number2>number3 && number2>number4 && number2>number5)
{
    console.log("Max Number:" + " " + number2);
}
else if (number3>number1 && number3>number2 && number3>number4 && number3>number5)
{
    console.log("Max Number:" + " " + number3);
}
else if (number4>number1 && number4>number3 && number4>number2 && number4>number5)
{
    console.log("Max Number:" + " " + number4);
}
else
{
    console.log("Max Number:" + " " + number5);
}


